package srpn;

import java.util.Stack;
import java.util.Random;

public class SRPN {
    private static final int MAX_STACK_SIZE = 23;
    private static final int MAX_INT = Integer.MAX_VALUE;
    private static final int MIN_INT = Integer.MIN_VALUE;

    private Stack<Integer> values = new Stack<>();
    private Random randomGenerator = new Random();
    private int randCount = 0;

    // Predefined random numbers for 'r' command
    private final int[] predefinedRandoms = {
        1804289383, 846930886, 1681692777, 1714636915, 1957747793,
        424238335, 719885386, 1649760492, 596516649, 1189641421,
        1025202362, 1350490027, 783368690, 1102520059, 2044897763,
        1967513926, 1365180540, 1540383426, 304089172, 1303455736,
        35005211, 521595368
    };

    public void runCommand(String input) {
        StringBuilder cleaned = new StringBuilder();
        boolean inComment = false;

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c == '#') {
                inComment = !inComment; // toggle comment mode
            } else if (!inComment) {
                cleaned.append(c);
            }
        }

        // Tokenize the cleaned input
        String[] tokens = cleaned.toString().trim().split("(?=[+\\-*/%^=dr])|(?<=[+\\-*/%^=dr])|\\s+");

        for (String token : tokens) {
            token = token.trim();
            if (token.isEmpty()) continue;

            if (isNumber(token)) {
                addNumber(token);
            } else if (token.length() == 1 && isOperator(token.charAt(0))) {
                applyOperator(token.charAt(0));
            } else {
                splitComplexToken(token);
            }
        }
    }

    private boolean isNumber(String s) {
        return s.matches("-?\\d+");
    }

    private boolean isOperator(char c) {
        return "+-*/%^=dr".indexOf(c) >= 0;
    }

    private void addNumber(String numStr) {
        try {
            long num = Long.parseLong(numStr);
            if (num > MAX_INT) num = MAX_INT;
            else if (num < MIN_INT) num = MIN_INT;

            if (values.size() >= MAX_STACK_SIZE) {
                System.out.println("Stack overflow.");
                return;
            }
            values.push((int) num);
        } catch (NumberFormatException e) {
            System.out.println("Unrecognised operator or operand \"" + numStr + "\"");
        }
    }

    private void applyOperator(char op) {
        switch (op) {
            case '+': doAdd(); break;
            case '-': doSubtract(); break;
            case '*': doMultiply(); break;
            case '/': doDivide(); break;
            case '%': doModulo(); break;
            case '^': doPower(); break;
            case '=': printTop(); break;
            case 'd': printStack(); break;
            case 'r': pushRandom(); break;
            default:
                System.out.println("Unrecognised operator or operand \"" + op + "\"");
        }
    }

    private void splitComplexToken(String token) {
        // Try to split tokens like "12-5" into "12", "-", "5"
        for (int i = 1; i < token.length() - 1; i++) {
            char c = token.charAt(i);
            if (c == '+' || c == '-') {
                String left = token.substring(0, i);
                String right = token.substring(i + 1);
                if (isNumber(left) && isNumber(right)) {
                    addNumber(left);
                    applyOperator(c);
                    addNumber(right);
                    return;
                }
            }
        }
        System.out.println("Unrecognised operator or operand \"" + token + "\"");
    }

    private void doAdd() {
        if (values.size() < 2) {
            System.out.println("Stack underflow.");
            return;
        }
        int b = values.pop();
        int a = values.pop();
        long res = (long) a + b;
        pushWithLimit(res);
    }

    private void doSubtract() {
        if (values.size() < 2) {
            System.out.println("Stack underflow.");
            return;
        }
        int b = values.pop();
        int a = values.pop();
        long res = (long) a - b;
        pushWithLimit(res);
    }

    private void doMultiply() {
        if (values.size() < 2) {
            System.out.println("Stack underflow.");
            return;
        }
        int b = values.pop();
        int a = values.pop();
        long res = (long) a * b;
        pushWithLimit(res);
    }

    private void doDivide() {
        if (values.size() < 2) {
            System.out.println("Stack underflow.");
            return;
        }
        int divisor = values.pop();
        int dividend = values.pop();
        if (divisor == 0) {
            System.out.println("Divide by 0.");
            values.push(dividend);
            values.push(divisor);
            return;
        }
        values.push(dividend / divisor);
    }

    private void doModulo() {
        if (values.size() < 2) {
            System.out.println("Stack underflow.");
            return;
        }
        int divisor = values.pop();
        int dividend = values.pop();
        if (divisor == 0) {
            System.out.println("Divide by 0.");
            values.push(dividend);
            values.push(divisor);
            return;
        }
        values.push(dividend % divisor);
    }

    private void doPower() {
        if (values.size() < 2) {
            System.out.println("Stack underflow.");
            return;
        }
        int exponent = values.pop();
        int base = values.pop();

        if (exponent < 0) {
            System.out.println("Negative power.");
            values.push(base);
            values.push(exponent);
            return;
        }

        long result = 1;
        for (int i = 0; i < exponent; i++) {
            result *= base;
            if (result > MAX_INT) {
                result = MAX_INT;
                break;
            }
            if (result < MIN_INT) {
                result = MIN_INT;
                break;
            }
        }
        pushWithLimit(result);
    }

    private void pushWithLimit(long val) {
        if (val > MAX_INT) val = MAX_INT;
        else if (val < MIN_INT) val = MIN_INT;
        values.push((int) val);
    }

    private void printTop() {
        if (values.isEmpty()) {
            System.out.println("Stack empty.");
        } else {
            System.out.println(values.peek());
        }
    }

    private void printStack() {
        if (values.isEmpty()) {
            System.out.println(MIN_INT);
        } else {
            for (int val : values) {
                System.out.println(val);
            }
        }
    }

    private void pushRandom() {
        if (values.size() >= MAX_STACK_SIZE) {
            System.out.println("Stack overflow.");
            return;
        }
        int randVal;
        if (randCount < predefinedRandoms.length) {
            randVal = predefinedRandoms[randCount];
        } else {
            randVal = randomGenerator.nextInt();
        }
        randCount++;
        values.push(randVal);
    }
}
