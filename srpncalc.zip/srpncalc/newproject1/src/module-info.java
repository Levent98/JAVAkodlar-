/**
 * 
 */
/**
 * 
 */
module newproject1 {
    exports srpn;
}