/**
 * 
 */
/**
 * 
 */
module newproject1 {
    exports srpn;
	requires junit;
	
}