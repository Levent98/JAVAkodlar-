package srpn;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.List;

public class SRPNTest {
    private SRPN srpn;

    @Before
    public void setUp() {
        srpn = new SRPN();
    }

    @Test
    public void testSingleNumber() {
        srpn.runCommand("5");
        assertEquals(1, srpn.getStackSize());
        assertEquals(5, srpn.getStackValue(0));
    }

    @Test
    public void testAddition() {
        srpn.runCommand("4");
        srpn.runCommand("6");
        srpn.runCommand("+");
        assertEquals(1, srpn.getStackSize());
        assertEquals(10, srpn.getStackValue(0));
    }

    @Test
    public void testSubtraction() {
        srpn.runCommand("10");
        srpn.runCommand("3");
        srpn.runCommand("-");
        assertEquals(1, srpn.getStackSize());
        assertEquals(7, srpn.getStackValue(0));
    }

    @Test
    public void testMultiplication() {
        srpn.runCommand("3");
        srpn.runCommand("4");
        srpn.runCommand("*");
        assertEquals(1, srpn.getStackSize());
        assertEquals(12, srpn.getStackValue(0));
    }

    @Test
    public void testDivision() {
        srpn.runCommand("12");
        srpn.runCommand("4");
        srpn.runCommand("/");
        assertEquals(1, srpn.getStackSize());
        assertEquals(3, srpn.getStackValue(0));
    }

    @Test
    public void testModulo() {
        srpn.runCommand("10");
        srpn.runCommand("4");
        srpn.runCommand("%");
        assertEquals(1, srpn.getStackSize());
        assertEquals(2, srpn.getStackValue(0));
    }

    @Test
    public void testPower() {
        srpn.runCommand("2");
        srpn.runCommand("3");
        srpn.runCommand("^");
        assertEquals(1, srpn.getStackSize());
        assertEquals(8, srpn.getStackValue(0));
    }

    @Test
    public void testNegativePower() {
        srpn.runCommand("2");
        srpn.runCommand("-3");
        srpn.runCommand("^");
        assertEquals(2, srpn.getStackSize());
        assertEquals(2, srpn.getStackValue(0));
        assertEquals(-3, srpn.getStackValue(1));
        assertTrue(srpn.getMessages().contains("Negative power."));
    }

    @Test
    public void testStackOverflow() {
        for (int i = 0; i < 25; i++) {
            srpn.runCommand("1");
        }
        assertEquals(23, srpn.getStackSize());
        assertTrue(srpn.getMessages().contains("Stack overflow."));
    }

    @Test
    public void testStackUnderflow() {
        srpn.runCommand("+");
        assertEquals(0, srpn.getStackSize());
        assertTrue(srpn.getMessages().contains("Stack underflow."));
    }

    @Test
    public void testDivideByZero() {
        srpn.runCommand("10");
        srpn.runCommand("0");
        srpn.runCommand("/");
        assertEquals(2, srpn.getStackSize());
        assertEquals(10, srpn.getStackValue(0));
        assertEquals(0, srpn.getStackValue(1));
        assertTrue(srpn.getMessages().contains("Divide by 0."));
    }

    @Test
    public void testRandom() {
        srpn.runCommand("r");
        assertEquals(1, srpn.getStackSize());
        assertEquals(1804289383, srpn.getStackValue(0));
    }

    @Test
    public void testCommentIgnored() {
        srpn.runCommand("5 # this is a comment # 3 +");
        assertEquals(1, srpn.getStackSize());
        assertEquals(5, srpn.getStackValue(0));
    }

    @Test
    public void testMultipleInOneLine() {
        srpn.runCommand("3 4 + 2 *");
        assertEquals(1, srpn.getStackSize());
        assertEquals(14, srpn.getStackValue(0));
    }

    @Test
    public void testClearStack() {
        srpn.runCommand("1 2 3");
        srpn.clearStack();
        assertEquals(0, srpn.getStackSize());
        assertTrue(srpn.getMessages().isEmpty());  // messages are cleared too
    }

    @Test
    public void testPrintTop() {
        srpn.runCommand("5");
        srpn.runCommand("=");
        List<String> output = srpn.getMessages();
        assertTrue(output.contains("5"));
    }

    @Test
    public void testPrintEmptyStack() {
        srpn.runCommand("=");
        assertTrue(srpn.getMessages().contains("Stack empty."));
    }

    @Test
    public void testPrintStack() {
        srpn.runCommand("1");
        srpn.runCommand("2");
        srpn.runCommand("d");
        List<String> messages = srpn.getMessages();
        assertTrue(messages.contains("1"));
        assertTrue(messages.contains("2"));
    }

    @Test
    public void testUnknownCommand() {
        srpn.runCommand("abc");
        assertTrue(srpn.getMessages().contains("Unrecognised operator or operand \"abc\""));
    }
}
