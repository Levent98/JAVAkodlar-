package srpn;

import java.util.*;

public class SRPN {
    private static final int MAX_STACK_SIZE = 23;
    private static final int MAX_INT = Integer.MAX_VALUE;
    private static final int MIN_INT = Integer.MIN_VALUE;

    private Stack<Integer> values = new Stack<>();
    private List<String> messages = new ArrayList<>();
    private Random randomGenerator = new Random();
    private int randCount = 0;

    private final int[] predefinedRandoms = {
        1804289383, 846930886, 1681692777, 1714636915, 1957747793,
        424238335, 719885386, 1649760492, 596516649, 1189641421,
        1025202362, 1350490027, 783368690, 1102520059, 2044897763,
        1967513926, 1365180540, 1540383426, 304089172, 1303455736,
        35005211, 521595368
    };

    public void runCommand(String input) {
        String cleanedInput = removeComments(input).trim();
        String[] tokens = cleanedInput.split("\\s+");

        for (String token : tokens) {
            if (token.isEmpty()) continue;

            if (isNumber(token)) {
                addNumber(token);
            } else if (token.length() == 1 && isOperator(token.charAt(0))) {
                applyOperator(token.charAt(0));
            } else {
                addMessage("Unrecognised operator or operand \"" + token + "\"");
            }
        }
    }

    private String removeComments(String input) {
        StringBuilder cleaned = new StringBuilder();
        boolean inComment = false;
        for (char c : input.toCharArray()) {
            if (c == '#') {
                inComment = !inComment;
            } else if (!inComment) {
                cleaned.append(c);
            }
        }
        return cleaned.toString();
    }

    private boolean isNumber(String s) {
        return s.matches("-?\\d+");
    }

    private boolean isOperator(char c) {
        return "+-*/%^=dr".indexOf(c) >= 0;
    }

    private void addNumber(String numStr) {
        try {
            long num = Long.parseLong(numStr);
            num = clamp(num);

            if (values.size() >= MAX_STACK_SIZE) {
                addMessage("Stack overflow.");
                return;
            }
            values.push((int) num);
        } catch (NumberFormatException e) {
            addMessage("Unrecognised operator or operand \"" + numStr + "\"");
        }
    }

    private void applyOperator(char op) {
        switch (op) {
            case '+': doAdd(); break;
            case '-': doSubtract(); break;
            case '*': doMultiply(); break;
            case '/': doDivide(); break;
            case '%': doModulo(); break;
            case '^': doPower(); break;
            case '=': printTop(); break;
            case 'd': printStack(); break;
            case 'r': pushRandom(); break;
            default:
                addMessage("Unrecognised operator or operand \"" + op + "\"");
        }
    }

    private void doAdd() {
        if (!hasEnoughOperands()) return;
        int b = values.pop();
        int a = values.pop();
        long res = (long) a + b;
        pushWithLimit(res);
    }

    private void doSubtract() {
        if (!hasEnoughOperands()) return;
        int b = values.pop();
        int a = values.pop();
        long res = (long) a - b;
        pushWithLimit(res);
    }

    private void doMultiply() {
        if (!hasEnoughOperands()) return;
        int b = values.pop();
        int a = values.pop();
        long res = (long) a * b;
        pushWithLimit(res);
    }

    private void doDivide() {
        if (!hasEnoughOperands()) return;
        int divisor = values.pop();
        int dividend = values.pop();
        if (divisor == 0) {
            addMessage("Divide by 0.");
            values.push(dividend);
            values.push(divisor);
            return;
        }
        values.push(dividend / divisor);
    }

    private void doModulo() {
        if (!hasEnoughOperands()) return;
        int divisor = values.pop();
        int dividend = values.pop();
        if (divisor == 0) {
            addMessage("Divide by 0.");
            values.push(dividend);
            values.push(divisor);
            return;
        }
        values.push(dividend % divisor);
    }

    private void doPower() {
        if (!hasEnoughOperands()) return;
        int exponent = values.pop();
        int base = values.pop();

        if (exponent < 0) {
            addMessage("Negative power.");
            values.push(base);
            values.push(exponent);
            return;
        }

        long result = 1;
        for (int i = 0; i < exponent; i++) {
            result *= base;
            if (result > MAX_INT || result < MIN_INT) {
                result = clamp(result);
                break;
            }
        }
        pushWithLimit(result);
    }

    private void pushRandom() {
        if (values.size() >= MAX_STACK_SIZE) {
            addMessage("Stack overflow.");
            return;
        }
        int randVal = randCount < predefinedRandoms.length ? predefinedRandoms[randCount] : randomGenerator.nextInt();
        randCount++;
        values.push(randVal);
    }

    private void printTop() {
        if (values.isEmpty()) {
            addMessage("Stack empty.");
        } else {
            addMessage(String.valueOf(values.peek()));
        }
    }

    private void printStack() {
        if (values.isEmpty()) {
            addMessage(String.valueOf(MIN_INT));
        } else {
            for (int val : values) {
                addMessage(String.valueOf(val));
            }
        }
    }

    private boolean hasEnoughOperands() {
        if (values.size() < 2) {
            addMessage("Stack underflow.");
            return false;
        }
        return true;
    }

    private void pushWithLimit(long val) {
        values.push((int) clamp(val));
    }

    private long clamp(long val) {
        return Math.max(MIN_INT, Math.min(MAX_INT, val));
    }

    private void addMessage(String msg) {
        messages.add(msg);
    }

    // Public methods for testing:
    public int getStackSize() {
        return values.size();
    }

    public int getStackValue(int index) {
        return values.get(index);
    }

    public void clearStack() {
        values.clear();
        randCount = 0;
        messages.clear();
    }

    public List<String> getMessages() {
        return new ArrayList<>(messages);
    }
}
