package srpn;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        SRPN srpn = new SRPN();
        try (Scanner scanner = new Scanner(System.in)) {
            while (scanner.hasNextLine()) {
                String input = scanner.nextLine();
                srpn.runCommand(input);
            
                // Prints all new messages to the console
                for (String message : srpn.getMessages()) {
                    System.out.println(message);
                }

                // to avoid duplication
                srpn.clearMessages();
                
        
            }
        }
    }
}