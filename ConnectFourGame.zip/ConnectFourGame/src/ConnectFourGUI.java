import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConnectFourGUI extends JFrame {

    private static final int ROWS = 6;
    private static final int COLS = 7;
    private static final int AI_DEPTH = 5; // Higher = smarter but slower

    private CellButton[][] boardButtons = new CellButton[ROWS][COLS];
    private char[][] board = new char[ROWS][COLS]; // 'r' for red, 'y' for yellow, ' ' empty

    private boolean redTurn = true; // red (human) starts
    private boolean gameOver = false;
    private boolean vsAI = true; // Play against AI

    public ConnectFourGUI() {
        setTitle("Connect Four");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 600);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(ROWS, COLS));
        initializeBoard(panel);

        getContentPane().add(panel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton restartButton = new JButton("Restart");
        restartButton.addActionListener(e -> restartGame());
        buttonPanel.add(restartButton);
        
        JToggleButton aiToggle = new JToggleButton("VS AI", vsAI);
        aiToggle.addActionListener(e -> {
            vsAI = aiToggle.isSelected();
            restartGame();
        });
        buttonPanel.add(aiToggle);

        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        initBoardState();

        setVisible(true);
    }

    private void initializeBoard(JPanel panel) {
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                CellButton button = new CellButton(row, col);
                button.setBackground(Color.WHITE);
                button.setOpaque(true);
                button.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                button.addActionListener(new ColumnClickListener(col));
                boardButtons[row][col] = button;
                panel.add(button);
            }
        }
    }

    private void initBoardState() {
        for (int r = 0; r < ROWS; r++)
            for (int c = 0; c < COLS; c++)
                board[r][c] = ' ';
        redTurn = true;
        gameOver = false;
        updateBoardUI();
    }

    private void updateBoardUI() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (board[r][c] == 'r') {
                    boardButtons[r][c].setBackground(Color.RED);
                } else if (board[r][c] == 'y') {
                    boardButtons[r][c].setBackground(Color.YELLOW);
                } else {
                    boardButtons[r][c].setBackground(Color.WHITE);
                }
            }
        }
    }

    private boolean placeCounter(int col) {
        if (col < 0 || col >= COLS) return false;
        for (int row = ROWS - 1; row >= 0; row--) {
            if (board[row][col] == ' ') {
                board[row][col] = redTurn ? 'r' : 'y';
                return true;
            }
        }
        return false; // column full
    }

    private boolean checkWin(char symbol) {
        // horizontal
        for (int r = 0; r < ROWS; r++)
            for (int c = 0; c < COLS - 3; c++)
                if (board[r][c] == symbol && board[r][c+1] == symbol && board[r][c+2] == symbol && board[r][c+3] == symbol)
                    return true;

        // vertical
        for (int r = 0; r < ROWS - 3; r++)
            for (int c = 0; c < COLS; c++)
                if (board[r][c] == symbol && board[r+1][c] == symbol && board[r+2][c] == symbol && board[r+3][c] == symbol)
                    return true;

        // diagonal down-right
        for (int r = 0; r < ROWS - 3; r++)
            for (int c = 0; c < COLS - 3; c++)
                if (board[r][c] == symbol && board[r+1][c+1] == symbol && board[r+2][c+2] == symbol && board[r+3][c+3] == symbol)
                    return true;

        // diagonal up-right
        for (int r = 3; r < ROWS; r++)
            for (int c = 0; c < COLS - 3; c++)
                if (board[r][c] == symbol && board[r-1][c+1] == symbol && board[r-2][c+2] == symbol && board[r-3][c+3] == symbol)
                    return true;

        return false;
    }

    private boolean isBoardFull() {
        for (int c = 0; c < COLS; c++)
            if (board[0][c] == ' ')
                return false;
        return true;
    }

    private void restartGame() {
        initBoardState();
    }

    private void makeAIMove() {
        if (!vsAI || redTurn || gameOver) return;
        
        // Use minimax algorithm to find best move
        int bestScore = Integer.MIN_VALUE;
        int bestCol = -1;
        
        for (int col = 0; col < COLS; col++) {
            if (board[0][col] != ' ') continue; // Column is full
            
            // Find the row where the piece would land
            int row = ROWS - 1;
            while (row >= 0 && board[row][col] != ' ') row--;
            
            if (row < 0) continue; // Column is full
            
            // Make the move
            board[row][col] = 'y';
            
            // Evaluate the move
            int score = minimax(board, AI_DEPTH, Integer.MIN_VALUE, Integer.MAX_VALUE, false);
            
            // Undo the move
            board[row][col] = ' ';
            
            if (score > bestScore) {
                bestScore = score;
                bestCol = col;
            }
        }
        
        if (bestCol != -1) {
            placeCounter(bestCol);
            updateBoardUI();
            checkGameState();
        }
    }

    private int minimax(char[][] board, int depth, int alpha, int beta, boolean maximizingPlayer) {
        // Check for terminal states
        if (checkWin('y')) return 1000 + depth; // AI wins (prefer faster wins)
        if (checkWin('r')) return -1000 - depth; // Human wins (prefer slower losses)
        if (isBoardFull() || depth == 0) return evaluateBoard();
        
        if (maximizingPlayer) {
            int maxEval = Integer.MIN_VALUE;
            for (int col = 0; col < COLS; col++) {
                if (board[0][col] != ' ') continue; // Column is full
                
                int row = ROWS - 1;
                while (row >= 0 && board[row][col] != ' ') row--;
                if (row < 0) continue;
                
                board[row][col] = 'y';
                int eval = minimax(board, depth - 1, alpha, beta, false);
                board[row][col] = ' ';
                
                maxEval = Math.max(maxEval, eval);
                alpha = Math.max(alpha, eval);
                if (beta <= alpha) break;
            }
            return maxEval;
        } else {
            int minEval = Integer.MAX_VALUE;
            for (int col = 0; col < COLS; col++) {
                if (board[0][col] != ' ') continue; // Column is full
                
                int row = ROWS - 1;
                while (row >= 0 && board[row][col] != ' ') row--;
                if (row < 0) continue;
                
                board[row][col] = 'r';
                int eval = minimax(board, depth - 1, alpha, beta, true);
                board[row][col] = ' ';
                
                minEval = Math.min(minEval, eval);
                beta = Math.min(beta, eval);
                if (beta <= alpha) break;
            }
            return minEval;
        }
    }

    private int evaluateBoard() {
        int score = 0;
        
        // Evaluate all possible 4-in-a-row segments
        score += evaluateSegments('y'); // AI
        score -= evaluateSegments('r'); // Human
        
        return score;
    }

    private int evaluateSegments(char player) {
        int score = 0;
        char opponent = (player == 'y') ? 'r' : 'y';
        
        // Evaluate horizontal segments
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS - 3; c++) {
                score += evaluateWindow(
                    board[r][c], board[r][c+1], board[r][c+2], board[r][c+3], 
                    player, opponent);
            }
        }
        
        // Evaluate vertical segments
        for (int c = 0; c < COLS; c++) {
            for (int r = 0; r < ROWS - 3; r++) {
                score += evaluateWindow(
                    board[r][c], board[r+1][c], board[r+2][c], board[r+3][c], 
                    player, opponent);
            }
        }
        
        // Evaluate diagonal (positive slope) segments
        for (int r = 0; r < ROWS - 3; r++) {
            for (int c = 0; c < COLS - 3; c++) {
                score += evaluateWindow(
                    board[r][c], board[r+1][c+1], board[r+2][c+2], board[r+3][c+3], 
                    player, opponent);
            }
        }
        
        // Evaluate diagonal (negative slope) segments
        for (int r = 3; r < ROWS; r++) {
            for (int c = 0; c < COLS - 3; c++) {
                score += evaluateWindow(
                    board[r][c], board[r-1][c+1], board[r-2][c+2], board[r-3][c+3], 
                    player, opponent);
            }
        }
        
        return score;
    }

    private int evaluateWindow(char p1, char p2, char p3, char p4, char player, char opponent) {
        int score = 0;
        
        // Count player and opponent pieces in the window
        int playerCount = 0;
        int opponentCount = 0;
        int emptyCount = 0;
        
        if (p1 == player) playerCount++;
        else if (p1 == opponent) opponentCount++;
        else emptyCount++;
        
        if (p2 == player) playerCount++;
        else if (p2 == opponent) opponentCount++;
        else emptyCount++;
        
        if (p3 == player) playerCount++;
        else if (p3 == opponent) opponentCount++;
        else emptyCount++;
        
        if (p4 == player) playerCount++;
        else if (p4 == opponent) opponentCount++;
        else emptyCount++;
        
        // Evaluate based on counts
        if (playerCount == 4) score += 100;
        else if (playerCount == 3 && emptyCount == 1) score += 5;
        else if (playerCount == 2 && emptyCount == 2) score += 2;
        
        if (opponentCount == 3 && emptyCount == 1) score -= 4;
        
        return score;
    }

    private void checkGameState() {
        char currentSymbol = redTurn ? 'r' : 'y';
        if (checkWin(currentSymbol)) {
            gameOver = true;
            String winner = redTurn ? "Red" : "Yellow";
            JOptionPane.showMessageDialog(ConnectFourGUI.this, winner + " player wins!");
            return;
        }

        if (isBoardFull()) {
            gameOver = true;
            JOptionPane.showMessageDialog(ConnectFourGUI.this, "It's a draw!");
            return;
        }

        redTurn = !redTurn; // switch turn
        
        // If playing against AI and it's AI's turn, make the move
        if (vsAI && !redTurn && !gameOver) {
            SwingUtilities.invokeLater(() -> {
                makeAIMove();
            });
        }
    }

    private class ColumnClickListener implements ActionListener {
        private int col;

        public ColumnClickListener(int col) {
            this.col = col;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (gameOver || (!redTurn && vsAI)) return;

            if (!placeCounter(col)) {
                JOptionPane.showMessageDialog(ConnectFourGUI.this, "Column is full! Try another column.");
                return;
            }

            updateBoardUI();
            checkGameState();
        }
    }

    private class CellButton extends JButton {
        private int row, col;
        public CellButton(int row, int col) {
            super();
            this.row = row;
            this.col = col;
            setPreferredSize(new Dimension(80, 80));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ConnectFourGUI());
    }
}